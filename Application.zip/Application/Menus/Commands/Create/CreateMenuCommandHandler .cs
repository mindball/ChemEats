﻿using Application.Common.Command;
using AutoMapper;
using Domain;
using Domain.Entities;
using Shared.DTOs.Menus;

namespace Application.Menus.Commands.Create;

public class CreateMenuCommandHandler : ICommandHandler<CreateMenuCommand, MenuDto>
{
    private readonly AppDbContext _context;
    private readonly IMapper _mapper;

    public CreateMenuCommandHandler(AppDbContext context, IMapper mapper)
    {
        _context = context;
        _mapper = mapper;
    }

    public async Task<MenuDto> HandleAsync(CreateMenuCommand command, CancellationToken cancellationToken = default)
    {
        var menu = Menu.Create(
            new SupplierId(command.SupplierId),
            command.Date,
            command.Meals.Select(m => Meal.Create(m.Name, m.Price))
        );

        _context.Menus.Add(menu);
        await _context.SaveChangesAsync(cancellationToken);

        return _mapper.Map<MenuDto>(menu);
    }
}