﻿using AutoMapper;
using Domain.Entities;
using Shared.DTOs.Menus;

namespace Application.Mappings;

public class MenuProfile : Profile
{
    public MenuProfile()
    {
        // Domain -> DTO
        CreateMap<Menu, MenuDto>();

        // Command -> Domain
        // CreateMap<CreateSupplierCommand, Supplier>()
        //     .ConstructUsing(src => Supplier.Create(src.Name, src.Menus));
    }
}