﻿using Application.Common.Command;
using AutoMapper;
using Domain.Entities;
using Domain.Repositories.Suppliers;
using Shared.DTOs.Suppliers;

namespace Application.Suppliers.Commands.Create;

public class CreateSupplierCommandHandler : ICommandHandler<CreateSupplierCommand, SupplierDto>
{
    private readonly ISupplierRepository _supplierRepository;
    private readonly IMapper _mapper;

    public CreateSupplierCommandHandler(ISupplierRepository supplierRepository, IMapper mapper)
    {
        _supplierRepository = supplierRepository;
        _mapper = mapper;
    }

    public async Task<SupplierDto> HandleAsync(CreateSupplierCommand command, CancellationToken cancellationToken)
    {
        var supplier = Supplier.Create(command.Name, command.VatNumber, command.PaymentTerms, command.Menus);
        await _supplierRepository.AddAsync(supplier, cancellationToken);
        return _mapper.Map<SupplierDto>(supplier);
    }
}