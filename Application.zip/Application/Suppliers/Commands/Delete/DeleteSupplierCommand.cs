﻿using Domain.Entities;

namespace Application.Suppliers.Commands.Delete;

public record DeleteSupplierCommand(Guid Id);