﻿using Application.Common.Command;
using AutoMapper;
using Domain.Repositories.Suppliers;
using Shared.DTOs.Suppliers;

namespace Application.Suppliers.Commands.Read;

public record GetSuppliersQuery;

public class GetSuppliersQueryHandler :
    ICommandHandler<GetSuppliersQuery, IEnumerable<SupplierDto>>
{
    private readonly ISupplierRepository _supplierRepository;
    private readonly IMapper _mapper;

    public GetSuppliersQueryHandler(
        ISupplierRepository supplierRepository,
        IMapper mapper)
    {
        _supplierRepository = supplierRepository;
        _mapper = mapper;
    }

    public async Task<IEnumerable<SupplierDto>> HandleAsync(
        GetSuppliersQuery query,
        CancellationToken cancellationToken = default)
    {
        var suppliers = await _supplierRepository.GetAllAsync(cancellationToken);

        return _mapper.Map<IEnumerable<SupplierDto>>(suppliers);
    }
}
