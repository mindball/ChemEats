﻿using Shared.DTOs.Meals;
using Shared.DTOs.Menus;

namespace Application.Menus.Commands.Create;

public record CreateMenuCommand(Guid SupplierId,
    DateOnly Date,
    List<MealDto> Meals);