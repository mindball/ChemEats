﻿using Application.Suppliers.Commands.Create;
using Domain.Entities;
using Shared.DTOs.Suppliers;
using AutoMapper;

namespace Application.Mappings;

public class SupplierProfile : Profile
{
    public SupplierProfile()
    {
        CreateMap<Supplier, SupplierDto>()
            .ForMember(dest => dest.Id, opt => opt.MapFrom(src => src.Id.Value));

        CreateMap<CreateSupplierCommand, Supplier>()
            .ConstructUsing(src => Supplier.Create(src.Name, src.VatNumber, src.PaymentTerms, src.Menus));

        CreateMap<SupplierRequest, CreateSupplierCommand>();

        CreateMap<SupplierDto, SupplierResponse>();
        
        CreateMap<SupplierDto, SupplierResponse>();
    }
}