﻿using Domain.Common.Enums;
using Domain.Entities;

namespace Application.Suppliers.Commands.Create;

public record CreateSupplierCommand(
    string Name,
    string VatNumber,
    PaymentTerms PaymentTerms,
    string? Email = null,
    string? Phone = null,
    string? StreetAddress = null,
    string? City = null,
    string? PostalCode = null,
    string? Country = null,
    IEnumerable<Menu>? Menus = null);