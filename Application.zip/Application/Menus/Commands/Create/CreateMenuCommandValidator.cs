﻿using FluentValidation;

namespace Application.Menus.Commands.Create;

public class CreateMenuCommandValidator : AbstractValidator<CreateMenuCommand>
{
    public CreateMenuCommandValidator()
    {
        RuleFor(x => x.SupplierId).NotEmpty();
        RuleFor(x => x.Date).NotEmpty();
        RuleFor(x => x.Meals).NotEmpty().WithMessage("Menu must contain at least one meal.");
        RuleForEach(x => x.Meals).ChildRules(meal =>
        {
            meal.RuleFor(m => m.Name).NotEmpty();
            meal.RuleFor(m => m.Price).GreaterThan(0);
        });
    }
}