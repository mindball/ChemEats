﻿using Application.Common.Command;
using Domain.Entities;
using Domain.Repositories.Suppliers;

namespace Application.Suppliers.Commands.Delete;

public class DeleteSupplierCommandHandler : ICommandHandler<DeleteSupplierCommand, bool>
{
    private readonly ISupplierRepository _supplierRepository;

    public DeleteSupplierCommandHandler(ISupplierRepository supplierRepository)
    {
        _supplierRepository = supplierRepository;
    }

    public async Task<bool> HandleAsync(DeleteSupplierCommand command, CancellationToken cancellationToken)
    {
        var supplierId = new SupplierId(command.Id);
        Supplier? supplier = await _supplierRepository.GetByIdAsync(supplierId, cancellationToken);
        if (supplier is null) return false; 

        await _supplierRepository.DeleteAsync(supplier, cancellationToken);
        return true;
    }
}